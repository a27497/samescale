"""Run the historical frontend commands in a fresh offline scratch copy.

Dependency links and compiler outputs never enter the submitted source tree.
"""
import shutil, subprocess, sys, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='ll-public-') as td:
 front=Path(td)/'frontend';shutil.copytree(root/'frontend',front)
 mods=front/'node_modules';mods.mkdir()
 for p in Path('/opt/ll-deps/node_modules').iterdir():
  if p.name not in ('.vite','.vite-temp'):(mods/p.name).symlink_to(p,target_is_directory=p.is_dir())
 for args in [['test:unit','--','--maxWorkers=1','--fileParallelism=false'],['type-check'],['build']]:
  print('+ npm run '+' '.join(args),flush=True)
  run=subprocess.run(['npm','run',*args],cwd=front)
  if run.returncode:sys.exit(run.returncode)
