import { defineStore } from "pinia";
import {
  connectTaskEvents,
  isTaskEventAuthError,
  toReadableTaskEventError,
} from "../api/taskEvents";
import type {
  AnalysisTaskStatus,
  TaskConnectionStatus,
  TaskEventMessage,
  TaskEventPayload,
} from "../types/task";

const TERMINAL_STATUSES = new Set<AnalysisTaskStatus>(["SUCCEEDED", "FAILED", "CANCELED"]);
const RECONNECT_DELAY_MS = 2000;

interface TaskEventsState {
  taskId: string;
  task: TaskEventPayload | null;
  connectionStatus: TaskConnectionStatus;
  errorMessage: string;
  lastHeartbeatAt: string;
  controller: AbortController | null;
  requestVersion: number;
  reconnectTimer: ReturnType<typeof setTimeout> | null;
}

export const useTaskEventsStore = defineStore("taskEvents", {
  state: (): TaskEventsState => ({
    taskId: "",
    task: null,
    connectionStatus: "idle",
    errorMessage: "",
    lastHeartbeatAt: "",
    controller: null,
    requestVersion: 0,
    reconnectTimer: null,
  }),

  getters: {
    isConnecting: (state) =>
      state.connectionStatus === "connecting" || state.connectionStatus === "reconnecting",
    isTerminal: (state) => (state.task ? TERMINAL_STATUSES.has(state.task.status) : false),
  },

  actions: {
    connect(taskId: string) {
      const normalizedTaskId = taskId.trim();
      this.closeCurrentConnection();
      if (this.taskId !== normalizedTaskId) {
        this.task = null;
        this.lastHeartbeatAt = "";
      }
      this.taskId = normalizedTaskId;
      this.errorMessage = "";

      if (!normalizedTaskId) {
        this.connectionStatus = "idle";
        this.errorMessage = "请提供任务 ID";
        return;
      }

      if (this.isTerminal) {
        this.connectionStatus = "closed";
        return;
      }

      this.startConnection(false);
    },

    startConnection(recovering: boolean) {
      this.closeCurrentConnection();
      if (!this.taskId || this.isTerminal) {
        return;
      }

      const currentVersion = this.requestVersion;
      const controller = new AbortController();
      this.controller = controller;
      this.connectionStatus = recovering ? "reconnecting" : "connecting";

      void connectTaskEvents({
        taskId: this.taskId,
        signal: controller.signal,
        onOpen: () => {
          if (this.isStale(currentVersion)) {
            return;
          }
          this.connectionStatus = "connected";
          this.errorMessage = "";
        },
        onMessage: (message) => {
          if (this.isStale(currentVersion)) {
            return;
          }
          this.applyMessage(message);
        },
      })
        .then(() => {
          if (this.isStale(currentVersion) || controller.signal.aborted) {
            return;
          }
          this.connectionStatus = this.isTerminal ? "closed" : "error";
          if (!this.isTerminal) {
            this.errorMessage = "任务事件流已断开，可重新连接";
            this.scheduleReconnect();
          }
        })
        .catch((error: unknown) => {
          if (this.isStale(currentVersion) || controller.signal.aborted) {
            return;
          }
          this.connectionStatus = "error";
          this.errorMessage = toReadableTaskEventError(error);
          if (isTaskEventAuthError(error)) {
            this.closeCurrentConnection();
          } else {
            this.scheduleReconnect();
          }
        });
    },

    scheduleReconnect() {
      // Retire this attempt before waiting, so even late callbacks cannot mutate state.
      this.closeCurrentConnection();
      if (!this.taskId || this.isTerminal) {
        return;
      }
      const currentVersion = this.requestVersion;
      this.reconnectTimer = setTimeout(() => {
        if (this.isStale(currentVersion)) {
          return;
        }
        this.reconnectTimer = null;
        this.startConnection(true);
      }, RECONNECT_DELAY_MS);
    },

    reconnect() {
      if (!this.taskId || this.isConnecting) {
        return;
      }
      this.connect(this.taskId);
    },

    disconnect() {
      this.closeCurrentConnection();
      this.connectionStatus = this.isTerminal ? "closed" : "idle";
    },

    applyMessage(message: TaskEventMessage) {
      if (message.data && this.taskId && message.data.taskId !== this.taskId) {
        return;
      }
      if (message.event === "heartbeat") {
        this.lastHeartbeatAt = new Date().toISOString();
        return;
      }

      if (message.data && !this.shouldKeepTerminalTask(message.data)) {
        this.task = message.data;
      }

      if (this.isTerminal || message.event === "completed" || message.event === "failed" || message.event === "canceled") {
        this.connectionStatus = "closed";
        this.closeCurrentConnection();
      }
    },

    shouldKeepTerminalTask(next: TaskEventPayload): boolean {
      return Boolean(
        this.task
        && TERMINAL_STATUSES.has(this.task.status)
        && !TERMINAL_STATUSES.has(next.status),
      );
    },

    closeCurrentConnection() {
      // Invalidate first: abort may itself cause callbacks from the retired stream.
      this.requestVersion += 1;
      if (this.reconnectTimer !== null) {
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = null;
      }
      const controller = this.controller;
      this.controller = null;
      controller?.abort();
    },

    isStale(version: number): boolean {
      return version !== this.requestVersion;
    },
  },
});
