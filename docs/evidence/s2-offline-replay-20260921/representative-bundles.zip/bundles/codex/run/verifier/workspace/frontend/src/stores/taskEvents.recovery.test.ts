import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createPinia, setActivePinia } from "pinia";
import { connectTaskEvents, TaskEventConnectionError } from "../api/taskEvents";
import { AccessTokenMissingError } from "../api/authToken";
import { AUTH_EXPIRED_MESSAGE } from "../utils/errorMessage";
import type { AnalysisTaskStatus, TaskEventMessage } from "../types/task";
import { useTaskEventsStore } from "./taskEvents";

vi.mock("../api/taskEvents", async (importOriginal) => ({
  ...await importOriginal<typeof import("../api/taskEvents")>(),
  connectTaskEvents: vi.fn(),
}));

type Options = Parameters<typeof connectTaskEvents>[0];
interface Attempt {
  options: Options;
  resolve: () => void;
  reject: (error: unknown) => void;
}

const attempts: Attempt[] = [];

function message(status: AnalysisTaskStatus = "RUNNING", taskId = "a"): TaskEventMessage {
  return {
    event: "snapshot",
    data: {
      taskId, status, progressPercent: 42, currentStage: "ASR",
      errorCode: null, errorMessage: null, updatedAt: "2026-07-31T03:47:20Z",
    },
  };
}

async function flush() {
  await Promise.resolve();
  await Promise.resolve();
}

describe("task event recovery", () => {
  beforeEach(() => {
    setActivePinia(createPinia());
    vi.useFakeTimers();
    attempts.length = 0;
    vi.mocked(connectTaskEvents).mockReset();
    vi.mocked(connectTaskEvents).mockImplementation((options) => new Promise<void>((resolve, reject) => {
      attempts.push({ options, resolve, reject });
    }));
  });

  afterEach(() => {
    useTaskEventsStore().disconnect();
    vi.useRealTimers();
  });

  it("recovers repeatedly after both transport failures and EOF, preserving progress", async () => {
    const store = useTaskEventsStore();
    store.connect("a");
    attempts[0].options.onOpen();
    attempts[0].options.onMessage(message());

    for (let index = 0; index < 12; index += 1) {
      const attempt = attempts[index];
      if (index % 2) attempt.resolve();
      else attempt.reject(new TypeError("network failure"));
      await flush();
      expect(store.task?.progressPercent).toBe(42);
      expect(attempts).toHaveLength(index + 1);
      expect(vi.getTimerCount()).toBe(1);
      const before = Date.now();
      await vi.advanceTimersToNextTimerAsync();
      expect(Date.now() - before).toBeGreaterThan(0);
      expect(Date.now() - before).toBeLessThanOrEqual(30_000);
      expect(attempts).toHaveLength(index + 2);
      expect(attempt.options.signal.aborted).toBe(true);
      expect(vi.getTimerCount()).toBe(0);
    }

    attempts.at(-1)!.options.onOpen();
    expect(store.connectionStatus).toBe("connected");
    expect(store.errorMessage).toBe("");
  });

  it.each(["SUCCEEDED", "FAILED", "CANCELED"] as const)("stops on a %s snapshot and ignores later callbacks", async (status) => {
    const store = useTaskEventsStore();
    store.connect("a");
    const old = attempts[0];
    old.options.onMessage(message(status));
    old.options.onMessage(message());
    old.options.onOpen();
    old.reject(new Error("late failure"));
    await flush();
    await vi.advanceTimersByTimeAsync(60_000);
    expect(store.task?.status).toBe(status);
    expect(store.connectionStatus).toBe("closed");
    expect(old.options.signal.aborted).toBe(true);
    expect(attempts).toHaveLength(1);
    store.reconnect();
    expect(store.task?.status).toBe(status);
    expect(attempts).toHaveLength(1);
    store.connect("b");
    expect(attempts).toHaveLength(2);
  });

  it.each(["completed", "failed", "canceled"] as const)("stops on a %s event without a payload", async (event) => {
    const store = useTaskEventsStore();
    store.connect("a");
    attempts[0].options.onMessage({ event, data: null });
    attempts[0].resolve();
    await flush();
    await vi.advanceTimersByTimeAsync(60_000);
    expect(store.connectionStatus).toBe("closed");
    expect(attempts).toHaveLength(1);
  });

  it.each([new AccessTokenMissingError(), new TaskEventConnectionError(AUTH_EXPIRED_MESSAGE)])("stops for authentication errors and permits an explicit new subscription", async (error) => {
    const store = useTaskEventsStore();
    store.connect("a");
    attempts[0].reject(error);
    await flush();
    attempts[0].options.onOpen();
    attempts[0].options.onMessage(message());
    await vi.advanceTimersByTimeAsync(60_000);
    expect(store.errorMessage).toBe(AUTH_EXPIRED_MESSAGE);
    expect(store.connectionStatus).toBe("error");
    expect(store.task).toBeNull();
    expect(attempts).toHaveLength(1);
    store.reconnect();
    expect(attempts).toHaveLength(2);
    attempts[1].options.onOpen();
    expect(store.connectionStatus).toBe("connected");
  });

  it.each([false, true])("disconnect cancels active or pending recovery (pending=%s)", async (pending) => {
    const store = useTaskEventsStore();
    store.connect("a");
    attempts[0].options.onMessage(message());
    if (pending) {
      attempts[0].resolve();
      await flush();
    }
    store.disconnect();
    attempts[0].options.onOpen();
    attempts[0].options.onMessage(message("SUCCEEDED"));
    attempts[0].reject(new Error("late failure"));
    await flush();
    await vi.advanceTimersByTimeAsync(60_000);
    expect(store.connectionStatus).toBe("idle");
    expect(store.task?.status).toBe("RUNNING");
    expect(attempts).toHaveLength(1);
    expect(vi.getTimerCount()).toBe(0);
  });

  it.each([false, true])("isolates late callbacks after switching tasks (EOF=%s)", async (eof) => {
    const store = useTaskEventsStore();
    store.connect("a");
    store.connect("b");
    attempts[1].options.onMessage(message("RUNNING", "b"));
    attempts[0].options.onOpen();
    attempts[0].options.onMessage(message("SUCCEEDED"));
    if (eof) attempts[0].resolve();
    else attempts[0].reject(new TaskEventConnectionError(AUTH_EXPIRED_MESSAGE));
    await flush();
    await vi.advanceTimersByTimeAsync(60_000);
    expect(store.task?.taskId).toBe("b");
    expect(store.connectionStatus).toBe("connecting");
    expect(store.errorMessage).toBe("");
    expect(attempts[1].options.signal.aborted).toBe(false);
    expect(attempts).toHaveLength(2);
  });

  it("isolates old callbacks from a recovered connection for the same task", async () => {
    const store = useTaskEventsStore();
    store.connect("a");
    attempts[0].resolve();
    await flush();
    await vi.advanceTimersToNextTimerAsync();
    attempts[1].options.onMessage(message());
    attempts[0].options.onOpen();
    attempts[0].options.onMessage(message("FAILED"));
    expect(store.connectionStatus).toBe("reconnecting");
    expect(store.task?.status).toBe("RUNNING");
    expect(attempts[1].options.signal.aborted).toBe(false);
  });

  it("manual reconnection replaces a scheduled retry without duplicate attempts", async () => {
    const store = useTaskEventsStore();
    store.connect("a");
    attempts[0].options.onMessage(message());
    attempts[0].reject(new TaskEventConnectionError("你没有权限操作这个资源"));
    await flush();
    expect(store.errorMessage).toBe("你没有权限操作这个资源");
    store.reconnect();
    store.reconnect();
    await vi.advanceTimersByTimeAsync(60_000);
    expect(attempts).toHaveLength(2);
    expect(store.task?.progressPercent).toBe(42);
    expect(store.errorMessage).toBe("");
  });

  it("switching tasks or clearing selection cancels the previous retry", async () => {
    const store = useTaskEventsStore();
    store.connect("a");
    attempts[0].resolve();
    await flush();
    store.connect("b");
    await vi.advanceTimersByTimeAsync(60_000);
    expect(attempts).toHaveLength(2);
    attempts[1].reject(new Error("failure"));
    await flush();
    store.connect(" ");
    await vi.advanceTimersByTimeAsync(60_000);
    expect(store.errorMessage).toBe("请提供任务 ID");
    expect(store.connectionStatus).toBe("idle");
    expect(attempts).toHaveLength(2);
  });
});
